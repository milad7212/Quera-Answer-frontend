const btn1 = document.getElementById('grey');
const btn2 = document.getElementById('white');
const btn3 = document.getElementById('blue');
const btn4 = document.getElementById('yellow');

btn1.addEventListener('click', function onClick() {
    document.body.style.backgroundColor = 'grey';
 
  
});
btn2.addEventListener('click', function onClick() {
    document.body.style.backgroundColor = 'white';
 
  
});
btn3.addEventListener('click', function onClick() {
    document.body.style.backgroundColor = 'blue';
 
  
});
btn4.addEventListener('click', function onClick() {
    document.body.style.backgroundColor = 'yellow';
 
  
});