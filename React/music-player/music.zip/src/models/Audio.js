export default new Audio();
