import Music_1 from "../assets/musics/1.mp3";
import Music_2 from "../assets/musics/2.mp3";
import Music_3 from "../assets/musics/3.mp3";
import Music_4 from "../assets/musics/4.mp3";
export default [
  {
    name: "Music_1",
    path: Music_1
  },
  {
    name: "Music_2",
    path: Music_2
  },
  {
    name: "Music_3",
    path: Music_3
  },
  {
    name: "Music_4",
    path: Music_4
  }
];
