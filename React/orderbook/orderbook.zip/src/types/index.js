export const ORDER_TYPE = {
  SELL: "sell",
  BUY: "buy",
};
