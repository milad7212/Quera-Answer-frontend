let btnType = document.getElementById("test-typing");
let btnEras = document.getElementById("test-erasing");
let text = document.getElementById("user-caption");
let span = document.getElementById("caption");

btnType.onclick = () => {
    let i = 0
    if (text.value == "") {
        span.innerHTML = "typing test!";
        return;
    }
    span.innerHTML = ''

    function typeWriter() {
        if (i < text.value.length) {
            span.innerHTML += text.value.charAt(i);
            i++;
            setTimeout(typeWriter, 30);
        }
    }
    typeWriter()


};

btnEras.onclick = () => {
    if (text.value == "") {
        span.innerHTML = "erasing test!";
    }
};